require("awful.layout.suit.max")
require("awful.layout.suit.tile")
require("awful.layout.suit.fair")
require("awful.layout.suit.floating")
require("awful.layout.suit.magnifier")
require("awful.layout.suit.spiral")

--- Suits for awful
module("awful.layout.suit")
